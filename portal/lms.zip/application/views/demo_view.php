<!DOCTYPE html> 
<html lang = "en">
 
   <head> 
      <meta charset = "utf-8"> 
      <title>Students Example</title> 
   </head> 
   <body> 
   <table align="center">
   <tr>
   <td><label>first Name</label></td>
   <td><input name="firstName" type="text" id="firstName" ></td>    
	</td> </tr>
	 <tr>
   <td><label>Last Name</label></td>
   <td><input name="lastName" type="text" id="lastName" ></td>    
	</td> </tr>
	 <tr>
   <td><label>email</label></td>
  <td> <input name="email" type="text" id="email" ></td>    
	</td> </tr>
	 <tr>
   <td><label>gender</label></td>
   <td><input name="gender" type="text" id="gender" ></td>    
	</td> </tr>
	 <tr>
   <td><label>birthdate</label></td>
   <td><input name="birthdate" type="text" id="birthdate" ></td>    
	</td> </tr>
	 <tr>
   <td><label>cellNo</label></td>
   <td><input name="cellNo" type="text" id="cellNo" ></td>    
	</td> </tr>
	 <tr>
   <td><label>password</label></td>
   <input name="password" type="text" id="password" >    
	</td> </tr>
	 <tr>
  
	<td><input type="submit" name="submit" value="submit"></td>
				  	
      </tr>
	  </table>          
				

                
				  
   </body>
</html>