<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
 
class demo_model extends CI_Model {
 
  public function __construct() {
    parent::__construct();
  }
  
  public function insert($data)
  {
  if($this->db->insert("registration",$data)){
  return true ;
  }
  }
  
}
?>  